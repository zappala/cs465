#!/usr/bin/env python3

from collections import defaultdict
import sys


def modmult(base, exp, mod, display=True):
    """ the wrong, inefficient way to do this """
    res = 1 
    for _ in range(exp):
        res *= base 
        res = res % mod
    if display:
        print("{0} : {1}".format(exp, res))
    return res

if len(sys.argv) != 4:
    print("%s generator prime count" % (sys.argv[0]))
    sys.exit()
generator, primep, count = [int(x) for x in sys.argv[1:]]

counts= defaultdict(int)
for k in range(1,count+1):
    counts[modmult(generator, k, primep)] += 1

print("Results\n------------")
for i in range(1,primep):
    print(i, counts[i])
