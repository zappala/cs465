#!/usr/bin/env python3

from collections import defaultdict
import sys


def modmult(base, exp, mod, display=True):
    res =  (base ** exp) % mod
    if display:
        print("{0} : {1}".format(exp, res))
    return res

#from https://linuxconfig.org/function-to-check-for-a-prime-number-with-python
def isprime(x):
    if x >= 2:
        for y in range(2,x):
            if not ( x % y ):
                return False
    else:
        return False
    return True



if len(sys.argv) != 4:
    print("%s generator prime count" % (sys.argv[0]))
    sys.exit()
generator, primeq, count = [int(x) for x in sys.argv[1:]]


primep = (2*primeq)+1
if not isprime(primep):
    print("{} ^ 2 + 1 is {} which is not prime".format(primeq, primep))
    sys.exit()



counts= defaultdict(int)
for k in range(1,count):
    counts[modmult(generator, k, primep)] += 1

print("Results\n------------")
for i in range(1,primep):
    print(i, counts[i])
print("-------------")
print("q = {}   p = {}  (p = 2q+1)".format(primeq, primep))
print("g^q = {0}".format(modmult(generator, primeq, primep, display=False)))
